%% Data sampling code for TPT data  
% Author: Wonjun Choi (wonjun@iis.u-tokyo.ac.jp) 
% Date: 2018.05.04

% This code was written to easily process TPT data presented in the paper entitled 
% "New perspectives in thermal performance test: Cost-effective apparatus and extended data analysis" 
% published in Energy and Buildings, 2018   

% The raw data were measured at 5-s intervals
% Each column in Excel sheet has the following 
% 1: Measured time, 2: Elapsed time [s] 3: Inlet temp. [��C], 4: Oulet temp. [��C], 5: Mean temp. [��C], 6: Flow rate [l/min]

% How to use this code: 
% 1) Select an experiment name (TPT30 or TPT40) 
% 2) Specify a time interval you want to thin out or average over 
% 3) After the execution, automatically three files will be generated in Excel format

% Decription of three Excel files: 
% 1) TPT##_instant_#min.xlsx: instantaneous data thinned out at #-min intervals
% 2) TPT##_averaged_#min.xlsx: averaged data over #-min intervals
% 3) TPT##_combined_#min.xlsx: instantaneous temperatures and averaged flow rate and heat rate are combined 

% Each column in Excel sheet: 
% 1: Elapsed time [s], 2: Inlet temp. [��C], 3: Oulet temp. [��C], 4: Meant temp. [��C], 5: Flow rate [l/min], 
% 6: heat rate [W/m], 7: Unit heat exchange rate per unit length [W/(mK)]

% For the purpose of validating parameter estimation method, or comparison of unit heat exchange rate (qu [W/(mK)]) 
% please use the file "TPTname_combined_#h.xlsx"  in which contains 
% instantaneous temperatures and time-interval averaged heat rate 

% You can freely use and modify this code and I inserted comments where needed 
% If you have any question, please send me an email 
% Enjoy!

clc; clear; close all;
%% 1. Excel data read 
recInt = 5;                 % data measurement interval 
min2Sec = 60;               % min -> sec
volCapFluid = 4.2*10^6;     % volumetric heat capacity of circulating fluid [J/m3K]     
lengthBHE = 50;             % length of BHE [m]
currPath = pwd;
addpath([currPath '\RawData']);   % add working path

TF = 1;
while any(TF) % Test input
    options.Resize = 'on'; options.WindowStyle = 'modal'; options.Interpreter = 'tex';
    dlgTitle = 'Specify sampling conditions';
    numInpLines = 1;
    prompt = {['Select experiment name (TPT30 or TPT40)'],...
        ['Time interval of thinning out (averaging) in MINUTE']};
    defAns  = {'TPT30', '60'};
    answer  = inputdlg(prompt, dlgTitle, numInpLines, defAns, options);
    TPTname = answer{1};          TF1 = isempty(TPTname);
    avgInt  = str2num(answer{2}); TF2 = isempty(avgInt);
    avgInt  = avgInt*min2Sec;
    TF = [TF1; TF2];
end

readFilename = [TPTname '_RawData_' num2str(recInt) 's'];
rawData = xlsread(readFilename, 'Sheet1');          %Read the raw data
heatRate = (rawData(:,2) - rawData(:,3)).*rawData(:,5)/1000/60*volCapFluid/lengthBHE; % heat injection rate [W/m]
heatRate(1) = 0;
tempDiff = rawData(:,4)-rawData(1,4);               % temperature difference, Tf - T0
unitHeatRate = heatRate./tempDiff;                  % unit heat exchange rate, qu [W/(mK)]
unitHeatRate(1) = 0;                        
rawData = [rawData heatRate unitHeatRate]; 
endRow = size(rawData,1);
endClmn = size(rawData,2); 

%% 2. Sample instantantaneous data 
instIniRow = rawData(1,:);          % save the first row of instant data
procData = rawData(2:endRow, :);    % without time column
sampledInstData = [instIniRow; procData(mod(procData(:,1),avgInt) == 0,:)]; 

%% 3. Averaged data    
avgRowNum = avgInt/recInt;                          % number of rows for averaging 
avgIterNum = floor(size(procData,1)/avgRowNum);     % iteration number

% initialize
avgTimeData = zeros(avgIterNum,1);
avgData = zeros(avgIterNum,size(procData,2)-1);

% Average process
h = waitbar(0, 'Data filtering, Please wait...');   
for i=1:avgIterNum
    avgTimeData(i,1) = procData(avgRowNum * i, 1);                                      % first column
    avgData(i,:) = sum(procData(avgRowNum*(i-1)+1:avgRowNum*(i), 2:end)) / avgRowNum;   % from second column    
    waitbar(i/avgIterNum, h); 
end
sampledAvgData = [instIniRow; avgTimeData avgData];

%% 4. Combined data 
sampledCombData = [sampledInstData(:,1:4) sampledAvgData(:,5:end)];

close(h); %close the wait bar
disp('Calculation has finished');

%% 5. Save results
saveFilename1 = [TPTname '_instant_' num2str(avgInt/60) 'min.xlsx'];     
saveFilename2 = [TPTname '_averaged_' num2str(avgInt/60) 'min.xlsx'];   
saveFilename3 = [TPTname '_combined_' num2str(avgInt/60) 'min.xlsx'];   

xlswrite(saveFilename1,sampledInstData);    % instantaneous value
xlswrite(saveFilename2,sampledAvgData);     % moving averaged value
xlswrite(saveFilename3,sampledCombData);    % instantneous temperature and averaged flow and heat rate 
